package Model;

public interface ChangeWorkMethod {
	boolean setWorkMethod(int startHour, boolean isHomeWorking);
}
