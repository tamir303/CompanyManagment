package Model;

public interface Profitable {
	double getEfficiency();
	String getProfit();
}
