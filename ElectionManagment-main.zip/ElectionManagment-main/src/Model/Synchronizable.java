package Model;

public interface Synchronizable extends ChangeWorkMethod {
	void setSyncable(boolean isSyncable);
}
